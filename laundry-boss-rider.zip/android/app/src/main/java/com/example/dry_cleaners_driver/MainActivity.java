package com.example.laundry_boss_rider;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
