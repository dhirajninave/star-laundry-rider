class AppConfig {
  AppConfig._();
  // static const String baseUrl = 'https://adminlaundry.razinsoft.com/api';
  static const String baseUrl = 'https://admin.laundryboss.app/api';

  // app name
  static const appName = "Laundry Boss Rider";
}
