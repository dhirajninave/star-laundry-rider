import 'dart:convert';

import 'package:laundry_boss_rider/features/auth/models/login_model/user.dart';

import 'address.dart';

class Customer {
  User? user;
  List<Address>? addresses;
  dynamic stripeId;

  Customer({this.user, this.addresses, this.stripeId});

  factory Customer.fromMap(Map<String, dynamic> data) => Customer(
        user: data['user'] == null
            ? null
            : User.fromMap(data['user'] as Map<String, dynamic>),
        addresses: (data['addresses'] as List<dynamic>?)
            ?.map((e) => Address.fromMap(e as Map<String, dynamic>))
            .toList(),
        stripeId: data['stripe_id'] as dynamic,
      );

  Map<String, dynamic> toMap() => {
        'user': user?.toMap(),
        'addresses': addresses?.map((e) => e.toMap()).toList(),
        'stripe_id': stripeId,
      };

  /// `dart:convert`
  ///
  /// Parses the string and returns the resulting Json object as [Customer].
  factory Customer.fromJson(String data) {
    return Customer.fromMap(json.decode(data) as Map<String, dynamic>);
  }

  /// `dart:convert`
  ///
  /// Converts [Customer] to a JSON string.
  String toJson() => json.encode(toMap());
}
